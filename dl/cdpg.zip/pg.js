/* Playgama Bridge pro CASTLE DIMENSION: game_ready, gameplay start/stop, ztlumení a reklama mezi bitvami */
(function () {
  var B = null, playing = false;
  function au(on) { try { if (typeof AU !== 'undefined' && AU.ctx) { on ? AU.ctx.resume() : AU.ctx.suspend(); } } catch (e) {} }
  function isPlay() {
    try {
      return !!((TD.active && !TD.paused && !TD.over && document.querySelector('#screen-game').classList.contains('on')) ||
        (CQ.active && !CQ.paused && !CQ.over && document.querySelector('#screen-battle').classList.contains('on')));
    } catch (e) { return false; }
  }
  if (!window.bridge || !bridge.initialize) return;
  bridge.initialize().then(function () {
    B = bridge; var E = B.EVENT_NAME || {};
    try { B.platform.on(E.AUDIO_STATE_CHANGED, function (en) { au(!!en); }); } catch (e) {}
    try { B.platform.on(E.PAUSE_STATE_CHANGED, function (p) { au(!p); }); } catch (e) {}
    try { B.advertisement.on(E.INTERSTITIAL_STATE_CHANGED, function (s) { if (s === 'opened') au(false); else if (s === 'closed' || s === 'failed') au(true); }); } catch (e) {}
    var go = function () {
      try { B.platform.sendMessage('game_ready'); } catch (e) {}
      setInterval(function () {
        var p = isPlay();
        if (p === playing) return;
        playing = p;
        try { B.platform.sendMessage(p ? 'gameplay_started' : 'gameplay_stopped'); } catch (e) {}
        if (!p) { try { B.advertisement.showInterstitial(); } catch (e) {} }
      }, 1000);
    };
    if (document.readyState === 'complete') setTimeout(go, 500); else window.addEventListener('load', function () { setTimeout(go, 500); });
  }).catch(function () {});
})();
