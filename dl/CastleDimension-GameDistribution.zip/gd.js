/* GameDistribution SDK pro CASTLE DIMENSION: reklama na začátku a mezi bitvami, ztlumení zvuku během reklamy */
window.GD_OPTIONS={gameId:"b2fd76e67ddc4a2d9246fb24b3237d5d",onEvent:function(e){
  try{ if(e.name==='SDK_GAME_PAUSE'&&typeof AU!=='undefined'&&AU.ctx) AU.ctx.suspend();
       if(e.name==='SDK_GAME_START'&&typeof AU!=='undefined'&&AU.ctx) AU.ctx.resume(); }catch(x){} }};
(function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(d.getElementById(id))return;js=d.createElement(s);js.id=id;js.src="https://html5.api.gamedistribution.com/main.min.js";fjs.parentNode.insertBefore(js,fjs)}(document,"script","gamedistribution-jssdk"));
(function(){
  var playing=false,played=false,last=0,first=true;
  function ad(){ try{ if(window.gdsdk&&gdsdk.showAd) gdsdk.showAd().catch(function(){}); }catch(e){} }
  function isPlay(){ try{ return !!((TD.active&&!TD.paused&&!TD.over&&document.querySelector('#screen-game').classList.contains('on'))||(CQ.active&&!CQ.paused&&!CQ.over&&document.querySelector('#screen-battle').classList.contains('on'))); }catch(e){ return false; } }
  document.addEventListener('pointerdown',function(){ if(first){ first=false; last=performance.now(); setTimeout(ad,200); } },true);
  setInterval(function(){ var p=isPlay(); if(p) played=true; if(p===playing) return; playing=p;
    if(!p&&played&&performance.now()-last>120000){ last=performance.now(); played=false; ad(); } },1000);
})();
